import React, { useState } from "react";
import { RouteComponentProps } from "react-router-dom";

import {
  signOut,
  useUserDispatch,
  useUserState,
} from "../../context/UserContext";
import {
  getSelectedProject,
  setSelectedSubmission,
} from "../../context/SharedContext";

import {
  IonButton,
  IonButtons,
  IonCard,
  IonCardContent,
  IonContent,
  IonFab,
  IonFabButton,
  IonHeader,
  IonIcon,
  IonInput,
  IonItem,
  IonLabel,
  IonModal,
  IonNote,
  IonPage,
  IonSearchbar,
  IonSegment,
  IonSegmentButton,
  IonTextarea,
  IonToolbar,
  IonList,
} from "@ionic/react";

import logo from "../../assets/img/logo-combination.png";
import {
  add,
  close,
  arrowBack,
  time,
  location,
  open,
  trash,
  pencil,
} from "ionicons/icons";
import "./Project.scss";
import { useLedger, useQuery, useStreamQueries } from "@daml/react";
import {
  AddChallenge,
  RemoveChallenge,
  ClientProject,
  ClientRole,
  ParticipantSubmission,
  ProposeSubmission,
  ModifieChallenge,
	Challenge,
} from "@daml.js/cosmart-0.0.1/lib/Main";
import submissionPlaceHolder from '../../assets/img/img-proj-placeholder.png'
import SubHeader from "../../components/Header/subheader";
const Project = (props: RouteComponentProps) => {
  const user = useUserState();
  var userDispatch = useUserDispatch();
  const ledger = useLedger();
  console.log("getSelectedProject", getSelectedProject());

  const selectedProj = useStreamQueries(ClientProject, () => [
    { projectId: getSelectedProject().payload.projectId },
  ]).contracts;
  const submissions = useStreamQueries(ParticipantSubmission, () => [
    { client: getSelectedProject().payload.client },
  ]).contracts;
  const client = useStreamQueries(ClientRole).contracts;
  const getUserType = (): "" | "client" | "participant" | "judge" => {
    if (
      selectedProj.filter(
        (c) => c.payload.participants.indexOf((user as any).party) > -1
      ).length > 0
    ) {
      return "participant";
    }
    if (
      selectedProj.filter((c) => (user as any).party === c.payload.client)
        .length > 0
    ) {
      return "client";
    }

    return "";
  };

  const [searchText, setSearchText] = useState("");
  const [showChallengeModal, setShowChallengeModal] = useState(false);
 
  const [
    showDltChallenderConfirmation,
    deleteChallenderConfirmation,
  ] = useState({ status: false, challengeID: "", contractID: "" });
  const [challengeIdTouched, setChallengeIdTouched] = useState(false);
  const defaultChallengeDetail: AddChallenge = {
    challengeId: "",
    nameOf: "",
    description: "",
    prize: "",
  };
  const [challengeDetail, setChallengeDetail] = useState(
    defaultChallengeDetail
  );
  const [showedtChallengeToggle, editChallengeToggle] = useState(false);
  const resetCreateChallenge = () => {
    setChallengeDetail(defaultChallengeDetail);
    setChallengeIdTouched(false);
  };

  const handleChallengeSubmit = async (evt: any) => {
    evt.preventDefault();
    ledger
      .exercise(
        ClientProject.AddChallenge,
        selectedProj[0]!.contractId,
        challengeDetail
      )
      .then(() => {
        setShowChallengeModal(false);
        alert("Challenge Created Successfully!");
        // reset project detail info
        setTimeout(() => {
          resetCreateChallenge();
          setTimeout(() => {
            console.log("selectedProj this >>", selectedProj);
          }, 1000);
        }, 250);
      })
      .catch((err: any) => {
        setShowChallengeModal(false);
        alert("Error: " + JSON.stringify(err));
      });
  };

  const formattedDate = (dateStr: string) => {
    const dateTimeFormatOptions: Intl.DateTimeFormatOptions = {
      year: "numeric",
      month: "numeric",
      day: "numeric",
      hour: "2-digit",
      hour12: false,
      minute: "2-digit",
    };
    return new Date(dateStr).toLocaleDateString("en-US", dateTimeFormatOptions);
  };

  const [selectedChallengeId, setSelectedChallengeId] = useState(0);
  const [showCreateSubmissionModal, setShowCreateSubmissionModal] = useState({
    show: false,
    challengeId: "",
  } as { show: boolean; challengeId?: string });
  const ChallengeCompoenent = (props: any) => {
    console.log("Challenge For customer",props.challengeId);
    const stream = useQuery(
      Challenge,
      () => ({ challengeId: props.challengeId }),
      []
    );
    console.log(
      "Challenge get",
      stream,
      "challengeId: props.challengeId=",
      props.challengeId
    );
      
    if ((stream.contracts || []).length > 0) {
      return (
        <IonCard>
          <div className="d-flex" id="view-project">
            {showedtChallengeToggle != props.challengeId ? (
              <IonCardContent className="list-item-data">
                {console.log("Contacr", stream.contracts[0].payload)}

                <h1 className="proj-chall-name">
                  {stream.contracts[0].payload.nameOf}{" "}
                  <IonNote>Id: {props.challengeId}</IonNote>
                </h1>
                <h2 className="proj-chall-example">Dolor sit amet</h2>
                <p className="proj-chall-description">
                {stream.contracts[0].payload.description}
                </p>
                <p>Fund: ${stream.contracts[0].payload.prize}</p>
                
                {getUserType() === "participant" ? (
                  <IonButton
                    onClick={() => {
                      setSelectedChallengeId(props.challengeId);
                      setShowCreateSubmissionModal({
                        show: true,
                        challengeId: props.challengeId,
                      });
                    }}
                    className="create-project-button"
                  >
                    {" "}
                    Create New Submission{" "}
                  </IonButton>
                ) : null}
                <IonIcon
                  icon={pencil}
                  onClick={() => {
                    editChallengeToggle(props.challengeId);
                  }}
                ></IonIcon>

                <IonIcon
                  icon={trash}
                  onClick={() => {
                    deleteChallenderConfirmation({
                      status: true,
                      challengeID: props.challengeId,
                      contractID: stream.contracts[0].contractId,
                    });
                  }}
                ></IonIcon>
              </IonCardContent>
            ) : (
              <IonCardContent className="editClient-challenge">
                <IonButton
                  fill="clear"
                  onClick={() => {
                    editChallengeToggle(false);
                  }}
                >
                  <IonIcon slot="start" icon={arrowBack}></IonIcon>
                  Back
                </IonButton>
                <div className="edi-challenge">
                  <form onSubmit={handleChallengeSubmission}>
                    <IonItem>
                      <IonLabel position="floating">Challenge Name</IonLabel>
                      <IonInput
                        required={true}
                        value={stream.contracts[0].payload.nameOf}
                        name="challengeName"
                      ></IonInput>
                    </IonItem>
                    <IonItem>
                      <IonLabel position="floating">Challenge ID</IonLabel>
                      <IonInput
                        required={true}
                        value={props.challengeId}
                        name="challengeId"
                      ></IonInput>
                    </IonItem>
                    <IonItem>
                      <IonLabel position="floating">
                        Challenge Description
                      </IonLabel>
                      <IonTextarea
                        required={true}
                        value={stream.contracts[0].payload.description}
                        name="challengeDesc"
                      ></IonTextarea>
                    </IonItem>

                    <IonItem>
                      <IonLabel position="floating">Challenge Price</IonLabel>
                     
                      <IonInput
                        required={true}
                        value={stream.contracts[0].contractId}
                        name="contractId"
                        className="hidden"
                      ></IonInput>
                      <IonInput
                        required={true}
                        value={stream.contracts[0].payload.prize}
                        name="challengePrize"
                      ></IonInput>
                    </IonItem>

                    <IonButton className="submit-button" type="submit">
                      Update Challenge
                    </IonButton>
                  </form>
                </div>
              </IonCardContent>
            )}
          </div>
        </IonCard>
      );
    } else return null;
  };

  const [selectedSegement, setSelectedSegement] = useState("submissions");

  const getChallengesIds = () => {
    return (
      (selectedProj && selectedProj.length > 0
        ? selectedProj[0]
        : { payload: {} }
      ).payload.challenges || []
    );
  };
  const deleteChallegeFromStorage = (challengeID: any, contractID: any) => {
    console.log(contractID);
    ledger
      .exercise(Challenge.RemoveChallenge, contractID, {
        comment: challengeID,
      })
      .then((data: any) => {
        console.log("Record Delete successfully");
        deleteChallenderConfirmation({
          status: false,
          challengeID: "",
          contractID: "",
        });
      })
      .catch((err: any) => console.log(err));
  };
  const handleChallengeSubmission = async (event: any) => {
    event.preventDefault();
    ledger
      .exercise(
        Challenge.ModifieChallenge,
        event.target.elements.contractId.value,
        {
          newname: event.target.elements.challengeName.value,
          newprize: event.target.elements.challengePrize.value,
					newdescription: event.target.elements.challengeDesc.value,
        }
      )
      .then((data: any) => {
        editChallengeToggle(false);
      })
      .catch((err: any) => {
        editChallengeToggle(false);
      });
    console.log(event.target.elements.challengeName.value);
  };
 
  const SubmissionFormComponent = (props: any) => {
    const defaultSubmissionDetail: ProposeSubmission = {
      challengeId: "",
      participant: (user as any).party,
      subName: "",
      subDesc: "",
      submission: "",
      judge: "Yuling",
      presentation: "",
      videoLink: "",
    };
    const [submissionDetail, setSubmissionDetail] = useState(
      defaultSubmissionDetail
    );
    const resetCreateSubmission = () => {
      setSubmissionDetail(defaultSubmissionDetail);
    };
    const handleCreateSubmission = async (evt: any) => {
      evt.preventDefault();
      const dataToExercise = submissionDetail;
      dataToExercise.challengeId = String(selectedChallengeId || 0);
      ledger
        .exercise(
          ClientProject.ProposeSubmission,
          selectedProj[0].contractId,
          dataToExercise
        )
        .then(() => {
          setShowCreateSubmissionModal({ show: false });
          alert("Submission Created Successfully!");
          // reset project detail info
          setTimeout(() => {
            resetCreateSubmission();
          }, 250);
        })
        .catch((err: any) => {
          setShowCreateSubmissionModal({ show: false });
          alert("Error: " + JSON.stringify(err));
        });
    };
    return (
      <>
        <div className="content create-project-modal-content">
          <form onSubmit={handleCreateSubmission}>
            <h1>Propose Submission</h1>
            <IonItem>
              <IonLabel position="floating">Submission Name*</IonLabel>
              <IonInput
                required={true}
                value={submissionDetail.subName}
                onIonChange={(e) =>
                  setSubmissionDetail({
                    ...submissionDetail,
                    subName: e.detail.value!,
                  })
                }
              ></IonInput>
            </IonItem>
            <IonItem>
              <IonLabel position="floating">Participant*</IonLabel>
              <IonInput
                required={true}
                value={submissionDetail.participant}
                onIonChange={(e) =>
                  setSubmissionDetail({
                    ...submissionDetail,
                    participant: e.detail.value!,
                  })
                }
              ></IonInput>
            </IonItem>
            <IonItem>
              <IonLabel position="floating">Submission Description*</IonLabel>
              <IonInput
                required={true}
                value={submissionDetail.subDesc}
                onIonChange={(e) =>
                  setSubmissionDetail({
                    ...submissionDetail,
                    subDesc: e.detail.value!,
                  })
                }
              ></IonInput>
            </IonItem>
            <IonItem>
              <IonLabel position="floating">Submission*</IonLabel>
              <IonInput
                required={true}
                value={submissionDetail.submission}
                onIonChange={(e) =>
                  setSubmissionDetail({
                    ...submissionDetail,
                    submission: e.detail.value!,
                  })
                }
              ></IonInput>
            </IonItem>
            <IonItem>
              <IonLabel position="floating">Presentation*</IonLabel>
              <IonInput
                required={true}
                value={submissionDetail.presentation}
                onIonChange={(e) =>
                  setSubmissionDetail({
                    ...submissionDetail,
                    presentation: e.detail.value!,
                  })
                }
              ></IonInput>
            </IonItem>
            <IonItem>
              <IonLabel position="floating">Video Link</IonLabel>
              <IonInput
                value={submissionDetail.videoLink}
                onIonChange={(e) =>
                  setSubmissionDetail({
                    ...submissionDetail,
                    videoLink: e.detail.value!,
                  })
                }
              ></IonInput>
            </IonItem>
            <IonItem>
              <IonLabel position="floating">Challenge Id</IonLabel>
              <IonInput
                required={true}
                disabled={true}
                value={
                  submissionDetail.challengeId ||
                  showCreateSubmissionModal.challengeId
                }
                onIonChange={(e) =>
                  setSubmissionDetail({
                    ...submissionDetail,
                    challengeId: e.detail.value!,
                  })
                }
              ></IonInput>
            </IonItem>
            <IonButton className="submit-button" type="submit">
              Create
            </IonButton>
          </form>
        </div>
        <IonButton
          className="modal-default-close-btn"
          fill="clear"
          color="danger"
          onClick={() => {
            resetCreateSubmission();
            setShowCreateSubmissionModal({ show: false });
          }}
        >
          <IonIcon icon={close}></IonIcon>
        </IonButton>
      </>
    );
  };

  return (
    <IonPage>
     <SubHeader  {...props}/>
      <IonContent>
        <div className="proj-wrapper">
          <IonButton fill="clear" onClick={(e) => props.history.goBack()}>
            <IonIcon slot="start" icon={arrowBack}></IonIcon>
            Back
          </IonButton>
          <IonCard>
            <img
              className="project-picture"
              src={getSelectedProject().payload.pictureUrl}
              alt="project image"
            />
            <IonCardContent>
              <div className="d-flex align-items-center justify-content-space-between">
                <IonLabel>
                  <div className="d-flex align-items-center">
                    <IonIcon
                      className="m-right"
                      slot="start"
                      icon={time}
                    ></IonIcon>
                    <span>
                      From:{" "}
                      {formattedDate(getSelectedProject().payload.startDate)},
                      to : {formattedDate(getSelectedProject().payload.endDate)}
                    </span>
                  </div>
                </IonLabel>
                <IonLabel>
                  <div className="d-flex align-items-center">
                    <IonIcon className="m-right" icon={location}></IonIcon>
                    {getSelectedProject().payload.location}
                  </div>
                </IonLabel>
                <IonButton>
                  <IonIcon slot="start" icon={open}></IonIcon>
                  Event WebSite
                </IonButton>
              </div>
            </IonCardContent>
          </IonCard>
          <h1>
            {getSelectedProject().payload.name}{" "}
            <IonNote>Id: {getSelectedProject().payload.projectId}</IonNote>
          </h1>
          <p>{getSelectedProject().payload.desc}</p>
          <IonNote>
            Judging criteria:{" "}
            {getSelectedProject()
              .payload.criteria.map((c: any) => c.name)
              .join(", ")}
          </IonNote>
          {
            <div className="text-align-start">
              <div className="pos-relative">
                <IonSegment
                  className="justify-content-start"
                  color="secondary"
                  onIonChange={(e) => setSelectedSegement(e.detail.value!)}
                  value={selectedSegement}
                >
                  <IonSegmentButton value="submissions">
                    <IonLabel>Submissions ({submissions.length})</IonLabel>
                  </IonSegmentButton>
                  <IonSegmentButton
                    value="challenges"
                    disabled={getChallengesIds().length < 1}
                  >
                    <IonLabel>
                       Challenges ({getChallengesIds().length})
                    </IonLabel>
                  </IonSegmentButton>
                </IonSegment>
              
                {getUserType() === "client" ? (
                  <div className="icon-menu">
                  <IonFab vertical="top" horizontal="end" title="Add new Challenge"> 
                    <IonFabButton title="Add new Challenge" onClick={(e) => setShowChallengeModal(true)}>
                      <IonIcon icon={add} />
                    </IonFabButton>
                  </IonFab>
                  {/*<IonFab className="submittionadd-btn" title="Add new Submission" vertical="top" horizontal="end">
                  <IonFabButton title="Add new Submission" onClick={(e) => setShowCreateSubmissionModal({show:true})}>
                    <IonIcon icon={add}/> 
                  </IonFabButton>
                </IonFab>*/}
                </div>
                ) : null}
              </div>
             
              {selectedSegement === "challenges"
                ? getChallengesIds().map((c) => (
                    <ChallengeCompoenent challengeId={c}></ChallengeCompoenent>
                  ))
                : submissions.map((sc) => (
                    <IonCard
                      className="submission-card"
                      onClick={(e) => {
                        e.preventDefault();
                        const selectedSub = sc as any;
                        selectedSub.payload.projectId = getSelectedProject().payload.projectId;
                        setSelectedSubmission(selectedSub);
                        props.history.push(
                          "/main/submission/" + sc.payload.submissionId
                        );
                      }}
                    >
                      <div className="d-flex">
                      <div className="submission-img">
                            <img src={submissionPlaceHolder} alt="submission image"/>
                        </div>
                        <IonCardContent>
                          <h1 className="proj-chall-name">
                            {sc.payload.name}
                          </h1>
                          <h2 className="proj-chall-example"> {sc.payload.submissionId}</h2>
                          <p className="proj-chall-description">
                            {sc.payload.desc}
                          </p>
                        
                        <IonList>
                          <IonItem>
                              <div className="labels-submission">Challenge ID : </div>
                              {sc.payload.challengeId}
                          </IonItem>
                          <IonItem>
                              <div className="labels-submission">Submission : </div>
                              {sc.payload.submission}
                          </IonItem>
                          <IonItem>
                              <div className="labels-submission">Presentation : </div>
                              {sc.payload.presentation}
                          </IonItem>
                          <IonItem>
                              <div className="labels-submission">Video Link : </div>
                              {sc.payload.videoLink}
                          </IonItem>
                        </IonList>
                        </IonCardContent>
                      </div>
                    </IonCard>
                  ))}
            </div>
          }
        </div>
        {/*-- Delete Project confirmation showDltChallenderConfirmation --*/}
        <IonModal
          isOpen={showDltChallenderConfirmation.status}
          onDidDismiss={() =>
            deleteChallenderConfirmation({
              status: false,
              challengeID: "",
              contractID: "",
            })
          }
          cssClass="my-custom-class-trash trash-popup"
        >
          <div className="content trash-project-modal-content">
            <h1>Are you sure !</h1>
            <IonButton
              className="confirm-submit-button"
              type="button"
              onClick={() => {
                deleteChallegeFromStorage(
                  showDltChallenderConfirmation.challengeID,
                  showDltChallenderConfirmation.contractID
                );
              }}
            >
              Yes
            </IonButton>
            <IonButton
              className="decline-submit-button"
              type="button"
              onClick={() => {
                deleteChallenderConfirmation({
                  status: false,
                  challengeID: "",
                  contractID: "",
                });
              }}
            >
              No
            </IonButton>
          </div>
          <IonButton
            className="modal-default-close-btn"
            fill="clear"
            color="danger"
            onClick={() => {
              deleteChallenderConfirmation({
                status: false,
                challengeID: "",
                contractID: "",
              });
            }}
          >
            <IonIcon icon={close}></IonIcon>
          </IonButton>
        </IonModal>
         {/*-- Challenge Model */}
        <IonModal
          isOpen={showChallengeModal}
          onDidDismiss={() => setShowChallengeModal(false)}
          cssClass="my-custom-class"
        >
          <div className="content challenge-modal-content">
            <h1>Create Challenge</h1>
            <form onSubmit={handleChallengeSubmit}>
              <div className="flex-equal-childs-width">
                <IonItem>
                  <IonLabel position="floating">Challenge Name</IonLabel>
                  <IonInput
                    required={true}
                    value={challengeDetail.nameOf}
                    onIonChange={(e) => {
                      let id = challengeDetail.challengeId;
                      if (!challengeIdTouched) {
                        const d = new Date();
                        id =
                          e.detail.value!.replace(/\W/g, "_") +
                          "_" +
                          (d.getSeconds() +
                            d.getMinutes() +
                            d.getMilliseconds());
                        id = id.toLowerCase();
                      }
                      setChallengeDetail({
                        ...challengeDetail,
                        nameOf: e.detail.value!,
                        challengeId: id,
                      });
                    }}
                  ></IonInput>
                </IonItem>
                <IonItem>
                  <IonLabel position="floating">Challenge ID</IonLabel>
                  <IonInput
                    required={true}
                    value={challengeDetail.challengeId}
                    onFocus={(e) => {
                      setChallengeIdTouched(true);
                    }}
                    onIonChange={(e) => {
                      setChallengeDetail({
                        ...challengeDetail,
                        challengeId: e.detail.value!,
                      });
                    }}
                  ></IonInput>
                </IonItem>
              </div>
              <IonItem>
                <IonLabel position="floating">Challenge Description</IonLabel>
                <IonTextarea
                  rows={2}
                  value={challengeDetail.description}
                  onIonChange={(e) =>
                    setChallengeDetail({
                      ...challengeDetail,
                      description: e.detail.value!,
                    })
                  }
                ></IonTextarea>
              </IonItem>
              <IonItem>
                <IonLabel position="floating">Challenge Prize</IonLabel>
                <IonInput
                  required={true}
                  type="number"
                  value={challengeDetail.prize}
                  onIonChange={(e) =>
                    setChallengeDetail({
                      ...challengeDetail,
                      prize: e.detail.value!,
                    })
                  }
                ></IonInput>
              </IonItem>
              <IonButton className="submit-button" type="submit">
                Create
              </IonButton>
            </form>
            <IonButton
              className="modal-default-close-btn"
              fill="clear"
              color="danger"
              onClick={() => {
                setShowChallengeModal(false);
              }}
            >
              <IonIcon icon={close}></IonIcon>
            </IonButton>
          </div>
        </IonModal>
        <IonModal
          isOpen={showCreateSubmissionModal.show}
          onDidDismiss={() => setShowCreateSubmissionModal({ show: false })}
          cssClass="my-custom-class"
        >
          <SubmissionFormComponent></SubmissionFormComponent>
        </IonModal>
      </IonContent>
    </IonPage>
  );
};
export default Project;
